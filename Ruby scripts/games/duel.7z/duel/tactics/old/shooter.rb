shooter = Tactic.new do |game|
  :fire
end