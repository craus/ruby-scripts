puts case 
  when true then 2
	when true then 3
	else 4
end