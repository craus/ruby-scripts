require 'win32console'
require_relative 'tools'

Dir["tactics/*.rb"].each do |file|
	require_relative file
end

compare Current, Warrior
























