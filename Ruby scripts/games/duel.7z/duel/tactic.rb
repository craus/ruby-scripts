class Tactic < Hash
end